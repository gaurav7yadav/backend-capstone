from rest_framework import serializers
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from .models import Product, Order, InventoryLog, Category


class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True)
    
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password')
    
    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password']
        )
        return user


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'
        read_only_fields = ('user',)


class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    class Meta:
        model = Product
        fields = '__all__'
        read_only_fields = ('user',)
    
    def validate_price(self, value):
        if value is not None and value < 0:
            raise serializers.ValidationError("Price can't be negative")
        return value
    
    def validate_quantity(self, value):
        if value is not None and value < 0:
            raise serializers.ValidationError("Number can't be negative")
        return value
    
    def validate(self, attrs):
        # Get the current user from the context (set in the view)
        user = self.context['request'].user if 'request' in self.context else None
        sku = attrs.get('sku')
        name = attrs.get('name')
        # Trim string fields
        if sku is not None:
            attrs['sku'] = sku.strip()
            if attrs['sku'] == '':
                raise serializers.ValidationError({'sku': 'SKU is required'})
        if name is not None:
            attrs['name'] = name.strip()
        
        if user and sku:
            # Check if this SKU already exists for this user
            # Exclude the current instance if we're updating
            existing = Product.objects.filter(user=user, sku=sku)
            if self.instance:
                existing = existing.exclude(pk=self.instance.pk)
            
            if existing.exists():
                raise serializers.ValidationError({
                    'sku': 'SKU must be unique for your account.'
                })
        
        return attrs


class OrderSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_category_name = serializers.CharField(source='product.category.name', read_only=True)
    
    class Meta:
        model = Order
        fields = '__all__'

    def validate_quantity(self, value):
        if value is None or value <= 0:
            raise serializers.ValidationError('Quantity must be greater than 0')
        return value

    def validate(self, attrs):
        # Ensure product belongs to the authenticated user at serializer level too
        request = self.context.get('request')
        product = attrs.get('product')
        quantity = attrs.get('quantity')
        if request and product and product.user_id != request.user.id:
            raise serializers.ValidationError({'product': 'You can only create orders for your own products'})
        # Redundant guard in case view checks change
        if product and quantity is not None and product.quantity < quantity:
            raise serializers.ValidationError({'quantity': 'Insufficient stock'})
        return attrs


class InventoryLogSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_sku = serializers.CharField(source='product.sku', read_only=True)
    
    class Meta:
        model = InventoryLog
        fields = '__all__'

    def validate_quantity(self, value):
        if value is None or value <= 0:
            raise serializers.ValidationError('Quantity must be greater than 0')
        return value

