# Generated manually to add user field to Product model

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


def assign_products_to_users(apps, schema_editor):
    """Assign existing products to users based on their orders"""
    Product = apps.get_model('inventory', 'Product')
    Order = apps.get_model('inventory', 'Order')
    
    # For each product, find the user from its first order
    for product in Product.objects.filter(user__isnull=True):
        # Try to find an order for this product
        order = Order.objects.filter(product=product).first()
        if order and order.user:
            # Assign product to the user who made the first order
            product.user = order.user
            product.save()
        # If no order exists, the product remains null (orphaned product)
        # Users will need to recreate products or we can assign to first user
        elif Order.objects.filter(product=product).exists() == False:
            # If product has no orders, try to get the first user
            User = apps.get_model(settings.AUTH_USER_MODEL)
            first_user = User.objects.first()
            if first_user:
                product.user = first_user
                product.save()


def reverse_assign_products_to_users(apps, schema_editor):
    """Reverse migration - set all products' user to null"""
    Product = apps.get_model('inventory', 'Product')
    Product.objects.all().update(user=None)


class Migration(migrations.Migration):

    dependencies = [
        ('inventory', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        # Remove unique constraint from sku field
        migrations.AlterField(
            model_name='product',
            name='sku',
            field=models.CharField(max_length=100),
        ),
        # Add user field to Product
        migrations.AddField(
            model_name='product',
            name='user',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL),
        ),
        # Run data migration to assign existing products to users
        migrations.RunPython(assign_products_to_users, reverse_assign_products_to_users),
        # Add unique_together constraint for sku and user
        migrations.AlterUniqueTogether(
            name='product',
            unique_together={('sku', 'user')},
        ),
    ]

