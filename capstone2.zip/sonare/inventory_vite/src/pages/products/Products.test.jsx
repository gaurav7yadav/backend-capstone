import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import API from '../services/api';
import Products from '../pages/products/Products';

vi.mock('../services/api');

describe('Products Component', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders products page with title', async () => {
    API.get.mockResolvedValue({ data: [] });
    
    render(
      <BrowserRouter>
        <Products />
      </BrowserRouter>
    );

    expect(screen.getByText('Products')).toBeInTheDocument();
  });

  it('displays products list', async () => {
    const mockProducts = [
      { id: 1, name: 'Product 1', sku: 'SKU001', quantity: 10, price: 100, category_name: 'Category 1' },
      { id: 2, name: 'Product 2', sku: 'SKU002', quantity: 20, price: 200, category_name: 'Category 2' }
    ];

    API.get.mockResolvedValue({ data: mockProducts });

    render(
      <BrowserRouter>
        <Products />
      </BrowserRouter>
    );

    await waitFor(() => {
      expect(screen.getByText('Product 1')).toBeInTheDocument();
      expect(screen.getByText('Product 2')).toBeInTheDocument();
    });
  });

  it('filters products by category', async () => {
    const mockProducts = [
      { id: 1, name: 'Product 1', sku: 'SKU001', quantity: 10, price: 100, category_name: 'Category 1' }
    ];

    API.get.mockImplementation((url) => {
      if (url.includes('categories')) {
        return Promise.resolve({ data: [{ id: 1, name: 'Category 1' }] });
      }
      return Promise.resolve({ data: mockProducts });
    });

    render(
      <BrowserRouter>
        <Products />
      </BrowserRouter>
    );

    await waitFor(() => {
      expect(API.get).toHaveBeenCalledWith('categories/');
    });
  });
});

