# Testing Guide

## Frontend Testing

### Setup
1. Install dependencies:
```bash
cd inventory_vite
npm install
```

### Run Tests
```bash
# Run all tests
npm test

# Run tests in watch mode
npm test -- --watch

# Run tests with UI
npm run test:ui

# Run tests with coverage
npm run test:coverage
```

### Test Files
- `src/pages/Dashboard.test.jsx` - Dashboard component tests
- `src/pages/products/Products.test.jsx` - Products component tests
- `src/utils/errorHandler.test.js` - Error handler tests

### Example Test Results
```
✓ Dashboard Component (3)
  ✓ renders dashboard title
  ✓ loads and displays stock chart data
  ✓ handles API errors gracefully

✓ Products Component (3)
  ✓ renders products page with title
  ✓ displays products list
  ✓ filters products by category

✓ ErrorHandler (3)
  ✓ handles API errors correctly
  ✓ handles network errors correctly
  ✓ handles 401 errors and redirects to login

Test Files  3 passed (3)
     Tests  9 passed (9)
```

## Backend Testing

### Setup
1. Install dependencies:
```bash
cd backend
pip install -r requirements.txt
```

### Run Tests
```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=inventory --cov-report=html

# Run specific test file
pytest inventory/tests/test_api.py

# Run with verbose output
pytest -v
```

### Test Files
- `inventory/tests/test_api.py` - API endpoint tests

### Example Test Results
```
================================ test session starts =================================
platform win32 -- Python 3.11.0, pytest-7.4.3
collected 14 items

inventory/tests/test_api.py::TestCategoryAPI::test_create_category PASSED
inventory/tests/test_api.py::TestCategoryAPI::test_list_categories PASSED
inventory/tests/test_api.py::TestCategoryAPI::test_delete_category PASSED
inventory/tests/test_api.py::TestProductAPI::test_create_product PASSED
inventory/tests/test_api.py::TestProductAPI::test_create_product_negative_quantity PASSED
inventory/tests/test_api.py::TestProductAPI::test_create_product_duplicate_sku PASSED
inventory/tests/test_api.py::TestProductAPI::test_list_products PASSED
inventory/tests/test_api.py::TestProductAPI::test_filter_products_by_category PASSED
inventory/tests/test_api.py::TestOrderAPI::test_create_order PASSED
inventory/tests/test_api.py::TestOrderAPI::test_create_order_insufficient_stock PASSED
inventory/tests/test_api.py::TestOrderAPI::test_update_order_status PASSED
inventory/tests/test_api.py::TestDashboardAPI::test_dashboard_stats PASSED
inventory/tests/test_api.py::TestAuthentication::test_unauthenticated_access_denied PASSED
inventory/tests/test_api.py::TestAuthentication::test_login_endpoint PASSED

================================= 14 passed in 2.34s =================================
```

## Test Coverage

### Frontend Coverage Goals
- Component rendering: 100%
- User interactions: 80%
- Error handling: 90%

### Backend Coverage Goals
- API endpoints: 100%
- Model validation: 100%
- Business logic: 90%

## Writing New Tests

### Frontend Test Example
```javascript
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import YourComponent from './YourComponent';

describe('YourComponent', () => {
  it('renders correctly', () => {
    render(<YourComponent />);
    expect(screen.getByText('Expected Text')).toBeInTheDocument();
  });
});
```

### Backend Test Example
```python
import pytest
from rest_framework.test import APIClient
from rest_framework import status

@pytest.mark.django_db
def test_your_endpoint(authenticated_client):
    url = reverse('your-endpoint')
    response = authenticated_client.get(url)
    assert response.status_code == status.HTTP_200_OK
```

