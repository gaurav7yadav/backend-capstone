import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import API from '../services/api';
import ErrorHandler from '../utils/errorHandler';
import Dashboard from '../pages/Dashboard';

// Mock API
vi.mock('../services/api');

describe('Dashboard Component', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders dashboard title', async () => {
    API.get.mockResolvedValue({ data: [] });
    
    render(
      <BrowserRouter>
        <Dashboard />
      </BrowserRouter>
    );

    expect(screen.getByText('Dashboard')).toBeInTheDocument();
  });

  it('loads and displays stock chart data', async () => {
    const mockChartData = {
      dates: ['2024-01-01', '2024-01-02'],
      stock_levels: [100, 150]
    };

    API.get.mockImplementation((url) => {
      if (url.includes('stock-chart')) {
        return Promise.resolve({ data: mockChartData });
      }
      return Promise.resolve({ data: [] });
    });

    render(
      <BrowserRouter>
        <Dashboard />
      </BrowserRouter>
    );

    await waitFor(() => {
      expect(API.get).toHaveBeenCalledWith('dashboard/stock-chart/');
    });
  });
});

describe('ErrorHandler', () => {
  it('handles API errors correctly', () => {
    const error = {
      response: {
        status: 404,
        statusText: 'Not Found',
        data: { message: 'Resource not found' }
      }
    };

    const result = ErrorHandler.handle(error, 'Test');
    expect(result.type).toBe('api_error');
    expect(result.code).toBe(404);
    expect(result.message).toBe('Resource not found');
  });

  it('handles network errors correctly', () => {
    const error = {
      request: {}
    };

    const result = ErrorHandler.handle(error, 'Test');
    expect(result.type).toBe('network_error');
    expect(result.message).toBe('Network error. Please check your connection.');
  });

  it('handles 401 errors and redirects to login', () => {
    const error = {
      response: {
        status: 401,
        statusText: 'Unauthorized'
      }
    };

    const mockRemoveItem = vi.fn();
    localStorage.removeItem = mockRemoveItem;

    ErrorHandler.handle(error, 'Test');
    expect(mockRemoveItem).toHaveBeenCalledWith('access');
  });
});

