# Inventory Frontend

React frontend for the Inventory Management System.

## Requirements
- Node >= 18, npm
- Backend running at http://localhost:8000/ with the API prefix `/api/`

## Setup (Windows)
1. Extract the zip and open terminal in project folder `inventory-frontend`
2. Install dependencies:
```
npm install
```
3. Start the development server:
```
npm start
```

The app expects backend endpoints to exist at:
- POST /api/register/
- POST /api/login/ (returns JSON with `access` token)
- CRUD endpoints: /api/products/, /api/orders/, /api/inventory/, /api/categories/
- Dashboard endpoints: /api/dashboard/stats/, /api/dashboard/stock-chart/

If your backend is served under a different host/port, update `src/services/api.js` baseURL.

## Notes
- Styling uses `styled-components`.
- Charts use `recharts`.
- Auth token is stored in `localStorage.access`. Adjust to your auth response shape if necessary.

