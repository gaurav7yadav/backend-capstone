import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import API from '../../services/api';
import styled from 'styled-components';

const Wrap = styled.div`max-width:var(--max-width);margin:24px auto;padding:16px;`;
const Table = styled.table`width:100%;border-collapse:collapse;background:${p=>p.theme.colors.card};border-radius:8px;overflow:hidden;`;
const Th = styled.th`text-align:left;padding:12px;border-bottom:1px solid #eee;`;
const Td = styled.td`padding:12px;border-bottom:1px solid #f4f4f4;cursor:default;`;

const Products = () => {
  const [products,setProducts]=useState([]);

  const load = async () => {
    const res = await API.get('products/');
    setProducts(res.data);
  };
  useEffect(()=>{ load(); },[]);

  const remove = async (id) => {
    if (!window.confirm('Delete product?')) return;
    await API.delete(`products/${id}/`);
    load();
  };

  return (
    <Wrap>
      <h2>Products</h2>
      <div style={{marginBottom:12}}>
        <Link to="/products/new">Add Product</Link>
      </div>

      <Table>
        <thead>
          <tr>
            <Th>Category</Th>
            <Th>Name</Th>
            <Th>SKU</Th>
            <Th>Quantity</Th>
            <Th>Price</Th>
            <Th>Actions</Th>
          </tr>
        </thead>

        <tbody>
          {products.map(p=>(
            <tr key={p.id}>
              {/* Category Column — supports both serializer outputs */}
              <Td>{p.category_name ? p.category_name : p.category?.name}</Td>
              <Td>{p.name}</Td>
              <Td>{p.sku}</Td>
              <Td>{p.quantity}</Td>
              <Td>{p.price}</Td>
              <Td>
                <Link to={`/products/${p.id}/edit`}>Edit</Link> 
                {' | '}
                <a style={{cursor:'pointer',color:'red'}} onClick={()=>remove(p.id)}>Delete</a>
              </Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Wrap>
  );
};

export default Products;
