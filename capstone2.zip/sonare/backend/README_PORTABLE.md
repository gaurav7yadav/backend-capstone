# How to Run Backend Separately After Zipping

## Files to Include in ZIP:

✅ **Include these:**
- `inventory/` (entire folder)
- `inventory_project/` (entire folder)
- `manage.py`
- `requirements.txt`
- `db.sqlite3` (if you want to keep existing data)
- Optional helper scripts (check_products.py, assign_products_to_users.py, etc.)

❌ **DO NOT Include these:**
- `venv/` folder (virtual environment - too large and machine-specific)
- `__pycache__/` folders (can be regenerated)
- `*.pyc` files (can be regenerated)

## Setup Instructions on New Machine:

### 1. Extract the ZIP file
Extract all files to a folder (e.g., `backend`)

### 2. Install Python
Make sure Python 3.8 or higher is installed:
```bash
python --version
```

### 3. Create Virtual Environment
```bash
cd backend
python -m venv venv
```

### 4. Activate Virtual Environment

**Windows:**
```bash
venv\Scripts\activate
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

### 5. Install Dependencies
```bash
pip install -r requirements.txt
```

### 6. Run Migrations
```bash
python manage.py migrate
```

### 7. (Optional) Create Superuser
```bash
python manage.py createsuperuser
```

### 8. Run the Server
```bash
python manage.py runserver
```

The API will be available at `http://localhost:8000`

## Important Notes:

1. **Database**: If you include `db.sqlite3`, all your data (users, products, orders) will be transferred. If you want a fresh start, delete `db.sqlite3` and run migrations.

2. **Port**: If port 8000 is in use, you can specify a different port:
   ```bash
   python manage.py runserver 8001
   ```

3. **CORS Settings**: The CORS settings are configured for `localhost:5173`. If your frontend runs on a different port, update `inventory_project/settings.py`:
   ```python
   CORS_ALLOWED_ORIGINS = [
       "http://localhost:5173",  # Your frontend URL
   ]
   ```

4. **Secret Key**: For production, change the `SECRET_KEY` in `settings.py` from the default value.

## Quick Start (All Commands):
```bash
# Extract ZIP
cd backend

# Setup
python -m venv venv
venv\Scripts\activate  # Windows
# OR
source venv/bin/activate  # Linux/Mac

pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

That's it! Your backend should now be running.

