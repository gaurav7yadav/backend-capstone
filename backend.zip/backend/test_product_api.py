"""
Quick test script to test product creation API
Run this from the backend directory: python test_product_api.py
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_project.settings')
django.setup()

from rest_framework.test import APIClient
from django.contrib.auth.models import User

# Create a test user
user, created = User.objects.get_or_create(username='testuser', defaults={'password': 'test123'})
if created:
    user.set_password('test123')
    user.save()

# Login and get token
client = APIClient()
response = client.post('/api/login/', {'username': 'testuser', 'password': 'test123'})
print("Login response:", response.status_code, response.data)

if response.status_code == 200:
    token = response.data.get('access')
    client.credentials(HTTP_AUTHORIZATION='Bearer ' + token)
    
    # Test product creation
    product_data = {
        'name': 'Test Product',
        'sku': 'TEST001',
        'quantity': 10,
        'price': '99.99',
        'description': 'Test description'
    }
    
    response = client.post('/api/products/', product_data)
    print("\nProduct creation response:")
    print("Status:", response.status_code)
    print("Data:", response.data)
else:
    print("Failed to login")

