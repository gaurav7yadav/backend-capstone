"""
Simple API Test Script
Run: python test_api_simple.py
"""
import requests

# API Base URL
BASE_URL = "http://localhost:8000/api"

print("=" * 60)
print("SIMPLE API TEST")
print("=" * 60)

# Step 1: Login
print("\n1. Logging in...")
login_data = {
    "username": input("Enter username (or press Enter for 'testuser'): ").strip() or "testuser",
    "password": input("Enter password (or press Enter for 'test123'): ").strip() or "test123"
}

login_response = requests.post(f"{BASE_URL}/login/", json=login_data)

if login_response.status_code == 200:
    token = login_response.json().get('access')
    print(f"✓ Login successful!")
    print(f"✓ Token: {token[:50]}...")
    
    # Step 2: Get Products
    print("\n2. Fetching products...")
    headers = {
        "Authorization": f"Bearer {token}"
    }
    
    products_response = requests.get(f"{BASE_URL}/products/", headers=headers)
    
    if products_response.status_code == 200:
        products = products_response.json()
        print(f"✓ Success! Found {len(products)} products:\n")
        print("-" * 60)
        for product in products:
            print(f"ID: {product['id']}")
            print(f"Name: {product['name']}")
            print(f"SKU: {product['sku']}")
            print(f"Quantity: {product['quantity']}")
            print(f"Price: ${product['price']}")
            print("-" * 60)
        
        # Check for earphone
        earphone = [p for p in products if 'earphone' in p['name'].lower()]
        if earphone:
            print(f"\n✓✓✓ EARPHONE FOUND in API:")
            for e in earphone:
                print(f"   - {e['name']} (ID: {e['id']}, SKU: {e['sku']})")
        else:
            print(f"\n✗ Earphone NOT found in API response")
            print("   Make sure the product exists in Django admin")
    else:
        print(f"✗ Error getting products: {products_response.status_code}")
        print(f"Response: {products_response.text}")
else:
    print(f"✗ Login failed: {login_response.status_code}")
    print(f"Response: {login_response.text}")
    print("\nTip: Make sure you have a user account registered.")

print("\n" + "=" * 60)

