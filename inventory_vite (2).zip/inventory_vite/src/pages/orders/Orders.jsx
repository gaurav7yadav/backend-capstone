import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
import API from "../../services/api";

const Page = styled.div`
  padding: 24px;
  max-width: 1000px;
  margin: 0 auto;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
`;

const Title = styled.h2`
  color: #1f2937;
`;

const Button = styled.button`
  background-color: ${(p) => (p.danger ? "#ef4444" : "#10b981")};
  color: white;
  border: none;
  padding: 10px 14px;
  border-radius: 6px;
  cursor: pointer;
  &:hover {
    background-color: ${(p) => (p.danger ? "#dc2626" : "#059669")};
  }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: ${(p) => p.theme.colors.card};
  border-radius: 8px;
  overflow: hidden;
`;

const Th = styled.th`
  text-align: left;
  padding: 12px;
  border-bottom: 1px solid #e5e7eb;
`;

const Td = styled.td`
  padding: 10px;
  border-bottom: 1px solid #f4f4f4;
`;

const Select = styled.select`
  padding: 6px;
  border-radius: 4px;
  border: 1px solid #d1d5db;
`;

const Orders = () => {
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    try {
      const res = await API.get("/orders/");
      setOrders(res.data);
    } catch (err) {
      console.error("Fetch Orders Error:", err);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const changeStatus = async (orderId, newStatus) => {
    try {
      await API.patch(`/orders/${orderId}/`, { status: newStatus });
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
      );
    } catch (err) {
      console.error("Status Update Error:", err);
    }
  };

  const handleDelete = async (orderId) => {
    if (!window.confirm("Are you sure you want to delete this order?")) return;
    try {
      await API.delete(`/orders/${orderId}/`);
      setOrders((prev) => prev.filter((o) => o.id !== orderId));
    } catch (err) {
      console.error("Delete Error:", err);
    }
  };

  return (
    <>
      <Page>
        <Header>
          <Title>Orders</Title>
          <Link to="/orders/new">
            <Button>Add Order</Button>
          </Link>
        </Header>

        <Table>
          <thead>
            <tr>
              <Th>Category</Th>
              <Th>Order</Th>
              <Th>Product</Th>
              <Th>Quantity</Th>
              <Th>Status</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => {
              const disabled = o.status?.toLowerCase() !== "pending";
              return (
                <tr key={o.id}>
                  <Td>{o.product_category_name}</Td>
                  <Td>Order #{o.id}</Td>
                  <Td>{o.product_name}</Td>
                  <Td>{o.quantity}</Td>
                  <Td>
                    <Select
                      value={o.status || "pending"}
                      onChange={(e) => changeStatus(o.id, e.target.value)}
                      disabled={disabled}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Completed">Completed</option>
                    </Select>
                  </Td>
                  <Td>
                    <Link to={`/orders/${o.id}/edit`}>
                      <Button disabled={disabled}>Edit</Button>
                    </Link>{" "}
                    <Button
                      danger
                      disabled={disabled}
                      onClick={() => handleDelete(o.id)}
                    >
                      Delete
                    </Button>
                  </Td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Page>
    </>
  );
};

export default Orders;
