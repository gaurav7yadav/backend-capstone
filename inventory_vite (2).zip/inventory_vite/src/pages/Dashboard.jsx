import React, { useEffect, useState } from 'react';
import API from '../services/api';
import styled from 'styled-components';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import Inventory from './inventory/Inventory';

const Wrap = styled.div`
  max-width: var(--max-width);
  margin: 24px auto;
  padding: 16px;
`;

const CardRow = styled.div`
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
  flex-wrap: wrap;
`;

const Card = styled.div`
  flex: 1;
  min-width: 220px;
  background: ${(p) => p.theme.colors.card};
  padding: 14px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.03);
`;

const Dashboard = () => {
  const [stats, setStats] = useState({});
  const [chart, setChart] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        const s = await API.get('dashboard/stats/');
        setStats(s.data);
      } catch (e) {
        console.error(e);
      }
      try {
        const c = await API.get('dashboard/stock-chart/');
        setChart(c.data);
      } catch (e) {
        console.error(e);
      }
    };
    load();
  }, []);

  return (
    <Wrap>
      <h2>Dashboard</h2>
      <CardRow>
        <Card>
          <h3>Total Products</h3>
          <div>{stats.total_products ?? '—'}</div>
        </Card>
        <Card>
          <h3>Total Orders</h3>
          <div>{stats.total_orders ?? '—'}</div>
        </Card>
        <Card>
          <h3>Low Stock Count</h3>
          <div>{stats.low_stock_count ?? '—'}</div>
        </Card>
      </CardRow>

      <Card>
        <h3>Stock Levels Over Time</h3>
        <div style={{ height: 300 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chart}>
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="stock" stroke="#8884d8" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Inventory Table below chart */}
      <Inventory />
    </Wrap>
  );
};

export default Dashboard;
