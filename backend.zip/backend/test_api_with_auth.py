"""
Test script to check products API with authentication
Run this from the backend directory: python test_api_with_auth.py
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_project.settings')
django.setup()

from django.contrib.auth.models import User
from rest_framework.test import APIClient
from inventory.models import Product

print("=" * 60)
print("TESTING PRODUCTS API WITH AUTHENTICATION")
print("=" * 60)

# Create or get test user
user, created = User.objects.get_or_create(
    username='testuser',
    defaults={'email': 'test@example.com'}
)
if created:
    user.set_password('test123')
    user.save()
    print("\n✓ Created test user: testuser / test123")
else:
    print("\n✓ Using existing test user: testuser")

# Login to get token
client = APIClient()
login_response = client.post('/api/login/', {
    'username': 'testuser',
    'password': 'test123'
})

if login_response.status_code == 200:
    token = login_response.data.get('access')
    print(f"✓ Login successful")
    print(f"✓ Token obtained: {token[:50]}...")
    
    # Set authentication header
    client.credentials(HTTP_AUTHORIZATION='Bearer ' + token)
    
    # Test products endpoint
    print("\n" + "=" * 60)
    print("TESTING /api/products/ ENDPOINT")
    print("=" * 60)
    response = client.get('/api/products/')
    
    print(f"\nStatus Code: {response.status_code}")
    
    if response.status_code == 200:
        products = response.data
        print(f"\n✓ Success! Found {len(products)} products:")
        print("-" * 60)
        for product in products:
            print(f"ID: {product['id']}")
            print(f"Name: {product['name']}")
            print(f"SKU: {product['sku']}")
            print(f"Quantity: {product['quantity']}")
            print(f"Price: {product['price']}")
            print("-" * 60)
        
        # Check for earphone
        earphone_products = [p for p in products if 'earphone' in p['name'].lower()]
        if earphone_products:
            print(f"\n✓ Earphone found in API response:")
            for e in earphone_products:
                print(f"  - {e['name']} (ID: {e['id']}, SKU: {e['sku']})")
        else:
            print(f"\n✗ Earphone NOT found in API response")
            print("  Make sure the product exists in the database")
    else:
        print(f"\n✗ Error: {response.status_code}")
        print(f"Response: {response.data}")
else:
    print(f"\n✗ Login failed: {login_response.status_code}")
    print(f"Response: {login_response.data}")

print("\n" + "=" * 60)
print("DIRECT DATABASE CHECK")
print("=" * 60)
db_products = Product.objects.all()
print(f"\nTotal products in database: {db_products.count()}")
for product in db_products:
    print(f"  - {product.name} (ID: {product.id}, SKU: {product.sku})")

earphone_db = Product.objects.filter(name__icontains='earphone')
if earphone_db.exists():
    print(f"\n✓ Earphone found in database:")
    for e in earphone_db:
        print(f"  - {e.name} (ID: {e.id}, SKU: {e.sku})")
else:
    print(f"\n✗ Earphone NOT found in database")

