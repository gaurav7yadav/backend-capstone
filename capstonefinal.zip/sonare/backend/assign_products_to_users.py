"""
Script to assign existing products to users based on their orders.
Run this from the backend directory: python assign_products_to_users.py
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_project.settings')
django.setup()

from django.contrib.auth.models import User
from inventory.models import Product, Order

print("=" * 60)
print("ASSIGNING PRODUCTS TO USERS")
print("=" * 60)

# Get all products without a user assigned
products_without_user = Product.objects.filter(user__isnull=True)
print(f"\nFound {products_without_user.count()} products without a user")

if products_without_user.count() == 0:
    print("\nAll products already have users assigned!")
else:
    assigned_count = 0
    
    for product in products_without_user:
        # Try to find an order for this product
        order = Order.objects.filter(product=product).first()
        if order and order.user:
            # Assign product to the user who made the first order
            product.user = order.user
            product.save()
            assigned_count += 1
            print(f"✓ Assigned product '{product.name}' (ID: {product.id}) to user '{order.user.username}'")
        else:
            # If no order exists, try to get the first user or assign to 'Sona'
            user = None
            try:
                user = User.objects.get(username='Sona')
            except User.DoesNotExist:
                user = User.objects.first()
            
            if user:
                product.user = user
                product.save()
                assigned_count += 1
                print(f"✓ Assigned product '{product.name}' (ID: {product.id}) to user '{user.username}' (no orders found)")
            else:
                print(f"✗ Could not assign product '{product.name}' (ID: {product.id}) - no users found")

    print(f"\n{'=' * 60}")
    print(f"Assignment complete! {assigned_count} products assigned to users.")
    print(f"{'=' * 60}")

# Show summary by user
print("\n" + "=" * 60)
print("PRODUCT SUMMARY BY USER")
print("=" * 60)
for user in User.objects.all():
    user_products = Product.objects.filter(user=user)
    user_orders = Order.objects.filter(user=user)
    print(f"\nUser: {user.username}")
    print(f"  Products: {user_products.count()}")
    print(f"  Orders: {user_orders.count()}")
    if user_products.exists():
        print("  Product list:")
        for p in user_products:
            print(f"    - {p.name} (SKU: {p.sku}, Stock: {p.quantity})")

