import pytest
from django.contrib.auth.models import User
from rest_framework.test import APIClient
from rest_framework import status
from inventory.models import Category, Product, Order
from django.urls import reverse


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def user():
    return User.objects.create_user(
        username='testuser',
        password='testpass123',
        email='test@example.com'
    )


@pytest.fixture
def authenticated_client(api_client, user):
    api_client.force_authenticate(user=user)
    return api_client


@pytest.fixture
def category(user):
    return Category.objects.create(name='Test Category', user=user)


@pytest.fixture
def product(user, category):
    return Product.objects.create(
        name='Test Product',
        sku='SKU001',
        quantity=100,
        price=50.00,
        user=user,
        category=category
    )


@pytest.mark.django_db
class TestCategoryAPI:
    def test_create_category(self, authenticated_client):
        """Test creating a new category"""
        url = reverse('category-list')
        data = {'name': 'New Category'}
        response = authenticated_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_201_CREATED
        assert Category.objects.filter(name='New Category').exists()

    def test_list_categories(self, authenticated_client, category):
        """Test listing categories"""
        url = reverse('category-list')
        response = authenticated_client.get(url)
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) == 1

    def test_delete_category(self, authenticated_client, category):
        """Test deleting a category"""
        url = reverse('category-detail', kwargs={'pk': category.id})
        response = authenticated_client.delete(url)
        assert response.status_code == status.HTTP_204_NO_CONTENT
        assert not Category.objects.filter(id=category.id).exists()


@pytest.mark.django_db
class TestProductAPI:
    def test_create_product(self, authenticated_client, category):
        """Test creating a new product"""
        url = reverse('product-list')
        data = {
            'name': 'New Product',
            'sku': 'SKU002',
            'quantity': 50,
            'price': 25.00,
            'category': category.id
        }
        response = authenticated_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_201_CREATED
        assert Product.objects.filter(sku='SKU002').exists()

    def test_create_product_negative_quantity(self, authenticated_client, category):
        """Test that negative quantity is rejected"""
        url = reverse('product-list')
        data = {
            'name': 'New Product',
            'sku': 'SKU003',
            'quantity': -10,
            'price': 25.00,
            'category': category.id
        }
        response = authenticated_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_create_product_duplicate_sku(self, authenticated_client, product):
        """Test that duplicate SKU is rejected"""
        url = reverse('product-list')
        data = {
            'name': 'Another Product',
            'sku': product.sku,
            'quantity': 50,
            'price': 25.00,
            'category': product.category.id
        }
        response = authenticated_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert 'unique' in str(response.data.get('sku', [])).lower()

    def test_list_products(self, authenticated_client, product):
        """Test listing products"""
        url = reverse('product-list')
        response = authenticated_client.get(url)
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) == 1

    def test_filter_products_by_category(self, authenticated_client, product, category):
        """Test filtering products by category"""
        url = reverse('product-list')
        response = authenticated_client.get(url, {'category': category.id})
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) == 1
        assert response.data[0]['name'] == product.name


@pytest.mark.django_db
class TestOrderAPI:
    def test_create_order(self, authenticated_client, product):
        """Test creating a new order"""
        url = reverse('order-list')
        data = {
            'product': product.id,
            'quantity': 10,
            'status': 'Pending'
        }
        response = authenticated_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_201_CREATED
        assert Order.objects.filter(product=product).exists()
        # Verify stock was reduced
        product.refresh_from_db()
        assert product.quantity == 90  # 100 - 10

    def test_create_order_insufficient_stock(self, authenticated_client, product):
        """Test that order with insufficient stock is rejected"""
        url = reverse('order-list')
        data = {
            'product': product.id,
            'quantity': 150,  # More than available
            'status': 'Pending'
        }
        response = authenticated_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_update_order_status(self, authenticated_client, product):
        """Test updating order status"""
        order = Order.objects.create(
            product=product,
            quantity=10,
            status='Pending',
            user=product.user
        )
        url = reverse('order-detail', kwargs={'pk': order.id})
        data = {'status': 'Shipped'}
        response = authenticated_client.patch(url, data, format='json')
        assert response.status_code == status.HTTP_200_OK
        order.refresh_from_db()
        assert order.status == 'Shipped'


@pytest.mark.django_db
class TestDashboardAPI:
    def test_dashboard_stats(self, authenticated_client, product):
        """Test dashboard stats endpoint"""
        url = reverse('dashboard_stats')
        response = authenticated_client.get(url)
        assert response.status_code == status.HTTP_200_OK
        assert 'total_products' in response.data
        assert 'total_orders' in response.data


@pytest.mark.django_db
class TestAuthentication:
    def test_unauthenticated_access_denied(self, api_client):
        """Test that unauthenticated users cannot access protected endpoints"""
        url = reverse('product-list')
        response = api_client.get(url)
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_login_endpoint(self, api_client, user):
        """Test login endpoint"""
        url = reverse('login')
        data = {
            'username': 'testuser',
            'password': 'testpass123'
        }
        response = api_client.post(url, data, format='json')
        assert response.status_code == status.HTTP_200_OK
        assert 'access' in response.data

