import React, { useEffect, useState } from 'react';
import API from '../../services/api';
import styled from 'styled-components';

const Wrap = styled.div`
  max-width: var(--max-width);
  margin: 24px auto;
  padding: 16px;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: ${(p) => p.theme.colors.card};
  border-radius: 8px;
  overflow: hidden;
`;

const Th = styled.th`
  text-align: left;
  padding: 12px;
  border-bottom: 1px solid #eee;
`;

const Td = styled.td`
  padding: 12px;
  border-bottom: 1px solid #f4f4f4;
`;

const Status = styled.span`
  color: ${(p) => (p.instock ? 'green' : 'red')};
  font-weight: 600;
`;

const Inventory = () => {
  const [products, setProducts] = useState([]);

  const load = async () => {
    try {
      const res = await API.get('products/'); // assuming your endpoint returns product list
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <Wrap>
      <h3 style={{ marginBottom: '12px' }}>Inventory Overview</h3>
      <Table>
        <thead>
          <tr>
            <Th>Category</Th>
            <Th>Product Name</Th>
            <Th>SKU</Th>
            <Th>Quantity</Th>
            <Th>Status</Th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id}>
              <Td>{p.category_name ? p.category_name : p.category?.name}</Td>
              <Td>{p.name}</Td>
              <Td>{p.sku}</Td>
              <Td>{p.quantity}</Td>
              <Td>
                <Status instock={p.quantity > 0}>
                  {p.quantity > 0 ? 'In Stock' : 'Out of Stock'}
                </Status>
              </Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Wrap>
  );
};

export default Inventory;
