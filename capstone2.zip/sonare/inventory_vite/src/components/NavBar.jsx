import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import styled from 'styled-components';

const Bar = styled.header`
  background: ${p=>p.theme.colors.card};
  padding: 12px 24px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.06);
`;

const Container = styled.div`
  max-width: var(--max-width);
  margin: 0 auto;
  display:flex;
  align-items:center;
  gap:16px;
`;

const Brand = styled.h1`
  font-size:22px;
  margin:0;
  color:${p=>p.theme.colors.primary};
`;

const Nav = styled.nav`
  margin-left:auto;
  display:flex;
  gap:12px;
  align-items:center;
`;

const NavLink = styled(Link)`
  padding:8px 10px;
  border-radius:6px;
  &:hover { background: #eef2f7; }
`;

const NavBar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const logout = () => {
    localStorage.removeItem('access');
    navigate('/login');
  };

  // Check if user is on Login or Register page
  const isAuthPage = location.pathname === '/login' || location.pathname === '/' || location.pathname === '/register';

  return (
    <Bar>
      <Container>
        <Brand>Inventory Manager</Brand>
        <Nav>
          {isAuthPage ? (
            <>
              <NavLink to="/login">Login</NavLink>
              <NavLink to="/register">Register</NavLink>
            </>
          ) : (
            <>
              <NavLink to="/dashboard">Dashboard</NavLink>
              <NavLink to="/products">Products</NavLink>
              <NavLink to="/orders">Orders</NavLink>
              <NavLink to="/category">Category</NavLink>
              <NavLink as="button" danger onClick={logout}>Logout</NavLink>
            </>
          )}
        </Nav>
      </Container>
    </Bar>
  );
};

export default NavBar;
