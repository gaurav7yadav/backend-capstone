const theme = {
  colors: {
    primary: '#2b6cb0',
    accent: '#ed64a6',
    bg: '#f6f8fa',
    card: '#fff'
  },
  spacing: (n) => `${n * 8}px`
};
export default theme;
