"""
Quick script to check if products exist in the database
Run this from the backend directory: python check_products.py
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_project.settings')
django.setup()

from inventory.models import Product, Order

print("=" * 50)
print("CHECKING PRODUCTS IN DATABASE")
print("=" * 50)

# Get all products
products = Product.objects.all()
print(f"\nTotal Products: {products.count()}")
print("\nAll Products:")
print("-" * 50)
for product in products:
    print(f"ID: {product.id}")
    print(f"Name: {product.name}")
    print(f"SKU: {product.sku}")
    print(f"Quantity: {product.quantity}")
    print(f"Price: {product.price}")
    print("-" * 50)

# Check specifically for earphone
earphone = Product.objects.filter(name__icontains='earphone')
print(f"\n\nEarphone Products Found: {earphone.count()}")
if earphone.exists():
    for e in earphone:
        print(f"  - ID: {e.id}, Name: {e.name}, SKU: {e.sku}, Quantity: {e.quantity}")
else:
    print("  No products found with 'earphone' in the name")
    
# Check orders
print("\n\n" + "=" * 50)
print("CHECKING ORDERS IN DATABASE")
print("=" * 50)
orders = Order.objects.all()
print(f"\nTotal Orders: {orders.count()}")
print("\nAll Orders:")
print("-" * 50)
for order in orders:
    print(f"Order ID: {order.id}")
    print(f"Product: {order.product.name} (ID: {order.product.id})")
    print(f"Quantity: {order.quantity}")
    print(f"Status: {order.status}")
    print("-" * 50)

